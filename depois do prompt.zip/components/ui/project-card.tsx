'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Camera, ArrowRight } from 'lucide-react'
import { Project, categoryLabels } from '@/data/projects'

interface ProjectCardProps {
  project: Project
  featured?: boolean
}

export function ProjectCard({ project, featured = false }: ProjectCardProps) {
  const [showBefore, setShowBefore] = useState(false)

  return (
    <motion.div 
      className={`group relative bg-[#111111] border border-[rgba(255,105,0,0.1)] overflow-hidden ${
        featured ? 'lg:col-span-2' : ''
      }`}
      style={{ borderRadius: '4px' }}
      layout
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4 }}
      whileHover={{ y: -4 }}
    >
      {/* Image container */}
      <div 
        className={`relative overflow-hidden ${featured ? 'aspect-[16/9]' : 'aspect-[4/3]'}`}
        onMouseEnter={() => setShowBefore(true)}
        onMouseLeave={() => setShowBefore(false)}
        onClick={() => setShowBefore(!showBefore)}
      >
        {/* 
          📸 FOTO NECESSÁRIA: projects/[id]-before.jpg e [id]-after.jpg
          O QUE DEVE SER: Fotos antes e depois do projeto
          DIMENSÕES IDEAIS: 800x600px (4:3) ou 1200x675px (16:9 para destaque)
        */}
        <div className="absolute inset-0 bg-[#1a1a1a] flex items-center justify-center">
          <Camera className="w-12 h-12 text-[#8A8A8A]/50" />
        </div>

        {/* Before/After toggle indicator */}
        <div className="absolute top-3 left-3 flex gap-2 z-10">
          <span 
            className={`px-2 py-1 text-xs font-[var(--font-barlow)] font-semibold uppercase tracking-wide transition-all ${
              showBefore 
                ? 'bg-[#CC1111] text-white' 
                : 'bg-[#111111]/80 text-[#8A8A8A]'
            }`}
          >
            Antes
          </span>
          <span 
            className={`px-2 py-1 text-xs font-[var(--font-barlow)] font-semibold uppercase tracking-wide transition-all ${
              !showBefore 
                ? 'bg-[#22c55e] text-white' 
                : 'bg-[#111111]/80 text-[#8A8A8A]'
            }`}
          >
            Depois
          </span>
        </div>

        {/* Category tag */}
        <span className="absolute top-3 right-3 bg-[#FF6900] text-[#0a0a0a] px-2 py-1 text-xs font-[var(--font-barlow)] font-bold uppercase tracking-wide z-10">
          {categoryLabels[project.category]}
        </span>

        {/* Hover overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />
      </div>

      {/* Content */}
      <div className="p-4 lg:p-5">
        <h3 className="font-[var(--font-barlow)] font-bold text-[#F5F5F3] text-lg mb-2 group-hover:text-[#FF6900] transition-colors">
          {project.title}
        </h3>
        <p className="font-sans text-[#8A8A8A] text-sm leading-relaxed line-clamp-2 mb-3">
          {project.description}
        </p>

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-3">
          {project.tags.slice(0, 3).map((tag, index) => (
            <span 
              key={index}
              className="text-xs text-[#8A8A8A] bg-[#1a1a1a] px-2 py-1"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between">
          <span className="text-xs text-[#8A8A8A]">{project.year}</span>
          <motion.span 
            className="flex items-center gap-1 text-[#FF6900] text-sm font-[var(--font-barlow)] font-semibold opacity-0 group-hover:opacity-100 transition-opacity"
            initial={{ x: -10 }}
            whileHover={{ x: 0 }}
          >
            Ver detalhes <ArrowRight className="w-4 h-4" />
          </motion.span>
        </div>
      </div>

      {/* Highlight indicator */}
      {project.highlight && (
        <div className="absolute top-0 left-0 w-1 h-full bg-[#FF6900]" />
      )}
    </motion.div>
  )
}
