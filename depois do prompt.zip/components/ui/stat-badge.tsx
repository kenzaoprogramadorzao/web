'use client'

import { useEffect, useRef, useState } from 'react'
import { motion, useInView } from 'framer-motion'

interface StatBadgeProps {
  number: string
  label: string
  suffix?: string
  animate?: boolean
}

export function StatBadge({ number, label, suffix = '', animate = true }: StatBadgeProps) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })
  const [displayNumber, setDisplayNumber] = useState(animate ? '0' : number)

  useEffect(() => {
    if (!animate || !isInView) return

    // Extract numeric value from the number string
    const numericValue = parseInt(number.replace(/\D/g, ''), 10)
    if (isNaN(numericValue)) {
      setDisplayNumber(number)
      return
    }

    const duration = 2000 // 2 seconds
    const steps = 60
    const stepValue = numericValue / steps
    let current = 0
    let step = 0

    const timer = setInterval(() => {
      step++
      current = Math.min(Math.round(stepValue * step), numericValue)
      
      // Format with K for thousands
      if (numericValue >= 1000) {
        setDisplayNumber(`${Math.round(current / 1000)}K`)
      } else {
        setDisplayNumber(`${current}`)
      }

      if (step >= steps) {
        clearInterval(timer)
        setDisplayNumber(number)
      }
    }, duration / steps)

    return () => clearInterval(timer)
  }, [isInView, number, animate])

  return (
    <motion.div 
      ref={ref}
      className="text-center"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      <span className="block font-[var(--font-bebas)] text-3xl sm:text-4xl lg:text-5xl text-[#FF6900] tracking-wide">
        {displayNumber}{suffix}
      </span>
      <span className="block font-[var(--font-barlow)] text-xs sm:text-sm uppercase tracking-wider text-[#8A8A8A] mt-1">
        {label}
      </span>
    </motion.div>
  )
}
