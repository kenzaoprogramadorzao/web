'use client'

import { motion } from 'framer-motion'
import { MessageCircle } from 'lucide-react'

interface CTASectionProps {
  headline: string
  subheadline?: string
  buttonText: string
  buttonLink: string
  variant?: 'orange' | 'dark'
}

export function CTASection({ 
  headline, 
  subheadline, 
  buttonText, 
  buttonLink,
  variant = 'orange'
}: CTASectionProps) {
  const isOrange = variant === 'orange'

  return (
    <section className={`relative py-16 lg:py-24 overflow-hidden ${
      isOrange 
        ? 'bg-gradient-to-br from-[#FF6900] via-[#FF6900] to-[#CC5500]' 
        : 'bg-[#0a0a0a] gradient-mesh'
    }`}>
      {/* Grain overlay */}
      <div className="grain-overlay absolute inset-0" />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.h2 
          className={`font-[var(--font-bebas)] headline-section tracking-wide mb-4 ${
            isOrange ? 'text-[#0a0a0a]' : 'text-[#F5F5F3]'
          }`}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          {headline}
        </motion.h2>

        {subheadline && (
          <motion.p 
            className={`font-[var(--font-barlow)] text-lg mb-8 ${
              isOrange ? 'text-[#0a0a0a]/80' : 'text-[#8A8A8A]'
            }`}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            {subheadline}
          </motion.p>
        )}

        <motion.a
          href={buttonLink}
          target="_blank"
          rel="noopener noreferrer"
          className={`inline-flex items-center gap-3 px-8 py-4 font-[var(--font-bebas)] text-xl tracking-wide transition-all ${
            isOrange 
              ? 'bg-[#F5F5F3] text-[#0a0a0a] hover:bg-white hover:shadow-[0_0_40px_rgba(255,255,255,0.3)]' 
              : 'bg-[#FF6900] text-[#0a0a0a] hover:bg-[#ff8533] hover:shadow-[0_0_40px_rgba(255,105,0,0.4)]'
          }`}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <MessageCircle className="w-5 h-5" />
          {buttonText}
        </motion.a>

        <motion.p 
          className={`mt-4 text-xs ${isOrange ? 'text-[#0a0a0a]/60' : 'text-[#8A8A8A]'}`}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          Resposta rápida · Sem compromisso · 30 anos de experiência
        </motion.p>
      </div>
    </section>
  )
}
