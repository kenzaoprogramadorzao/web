export type ProjectCategory = 
  | 'funilaria-pintura' 
  | 'tunning' 
  | 'estetica' 
  | 'performance' 
  | 'martelinho'

export type Project = {
  id: string
  title: string
  category: ProjectCategory
  tags: string[]
  description: string
  beforeImage: string
  afterImage: string
  highlight: boolean
  year: number
  client?: string
  isFamoso?: boolean // Projeto de famoso/celebridade
}

export const categoryLabels: Record<ProjectCategory, string> = {
  'funilaria-pintura': 'Funilaria & Pintura',
  'tunning': 'Tunning',
  'estetica': 'Estética',
  'performance': 'Alta Performance',
  'martelinho': 'Martelinho de Ouro'
}

export const projects: Project[] = [
  {
    id: 'project-001',
    title: 'Civic Si — Pintura Candy Red Completa',
    category: 'funilaria-pintura',
    tags: ['Honda Civic', 'Candy Red', 'Pintura Completa'],
    description: 'Reforma completa da pintura com candy red metálico, correção de amassados e acabamento espelhado.',
    beforeImage: '/images/projects/civic-before.jpg',
    afterImage: '/images/projects/civic-after.jpg',
    highlight: true,
    year: 2024,
    client: 'Cliente VIP',
    isFamoso: true
  },
  {
    id: 'project-002',
    title: 'Golf GTI — Wrap Preto Fosco + Detalhes em Carbono',
    category: 'tunning',
    tags: ['VW Golf', 'Wrap', 'Carbono', 'Envelopamento'],
    description: 'Envelopamento completo em preto fosco com detalhes em fibra de carbono real no capô e retrovisores.',
    beforeImage: '/images/projects/golf-before.jpg',
    afterImage: '/images/projects/golf-after.jpg',
    highlight: true,
    year: 2024
  },
  {
    id: 'project-003',
    title: 'Porsche 911 — Polimento Técnico e Vitrificação',
    category: 'estetica',
    tags: ['Porsche', 'Polimento', 'Vitrificação', 'Cerâmica'],
    description: 'Correção de pintura em 3 etapas com polimento técnico e aplicação de coating cerâmico 9H.',
    beforeImage: '/images/projects/porsche-before.jpg',
    afterImage: '/images/projects/porsche-after.jpg',
    highlight: false,
    year: 2024
  },
  {
    id: 'project-004',
    title: 'BMW M3 — Preparação Completa para Track Day',
    category: 'performance',
    tags: ['BMW M3', 'Track Day', 'Suspensão', 'Freios'],
    description: 'Upgrade de suspensão coilover, freios Brembo, escape esportivo e remapeamento de ECU.',
    beforeImage: '/images/projects/bmw-before.jpg',
    afterImage: '/images/projects/bmw-after.jpg',
    highlight: true,
    year: 2023,
    isFamoso: true
  },
  {
    id: 'project-005',
    title: 'Mercedes C300 — Remoção de Amassados PDR',
    category: 'martelinho',
    tags: ['Mercedes', 'PDR', 'Martelinho', 'Sem Pintura'],
    description: 'Reparação de 12 amassados causados por granizo utilizando técnica PDR sem necessidade de repintura.',
    beforeImage: '/images/projects/mercedes-before.jpg',
    afterImage: '/images/projects/mercedes-after.jpg',
    highlight: false,
    year: 2024
  },
  {
    id: 'project-006',
    title: 'Mustang GT — Pintura Racing Stripes',
    category: 'funilaria-pintura',
    tags: ['Ford Mustang', 'Racing Stripes', 'Personalização'],
    description: 'Aplicação de faixas racing clássicas em branco sobre azul metálico, acabamento impecável.',
    beforeImage: '/images/projects/mustang-before.jpg',
    afterImage: '/images/projects/mustang-after.jpg',
    highlight: false,
    year: 2023
  },
  {
    id: 'project-007',
    title: 'Camaro SS — Kit Aerodinâmico + Rodas',
    category: 'tunning',
    tags: ['Chevrolet Camaro', 'Aerodinâmico', 'Rodas', 'Rebaixamento'],
    description: 'Instalação de kit aerodinâmico widebody, rodas aro 20 forjadas e suspensão a ar.',
    beforeImage: '/images/projects/camaro-before.jpg',
    afterImage: '/images/projects/camaro-after.jpg',
    highlight: false,
    year: 2023
  },
  {
    id: 'project-008',
    title: 'Audi RS6 — Restauração de Pintura Original',
    category: 'funilaria-pintura',
    tags: ['Audi RS6', 'Restauração', 'Pintura Original'],
    description: 'Restauração completa da pintura original Nardo Grey com correção de riscos profundos e re-clear.',
    beforeImage: '/images/projects/audi-before.jpg',
    afterImage: '/images/projects/audi-after.jpg',
    highlight: false,
    year: 2024
  }
]
