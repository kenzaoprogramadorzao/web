'use client'

import { useState, useRef } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { 
  MessageCircle, 
  ArrowRight, 
  SprayCan, 
  Hammer, 
  Gauge, 
  Zap, 
  Sparkles, 
  Box,
  Youtube,
  Instagram,
  Play,
  Heart,
  Camera,
  Star,
  Mic,
  Trophy,
  Tv,
  ChevronLeft,
  ChevronRight as ChevronRightIcon
} from 'lucide-react'
import { SectionHeader } from '@/components/ui/section-header'
import { StatBadge } from '@/components/ui/stat-badge'
import { ServiceCard } from '@/components/ui/service-card'
import { TestimonialCard } from '@/components/ui/testimonial-card'
import { CTASection } from '@/components/ui/cta-section'
import { ProjectCard } from '@/components/ui/project-card'
import { projects } from '@/data/projects'

const WHATSAPP_LINK = 'https://wa.me/5511999999999'
const INSTAGRAM_LINK = 'https://www.instagram.com/nascarautosport/'
const YOUTUBE_LINK = 'https://www.youtube.com/channel/UCVQtm9415r8NqXuC_AloQHQ'

const fadeInUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' } }
}

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
}

const services = [
  { icon: SprayCan, title: 'Funilaria & Pintura', description: 'Pintura personalizada, candy, metalica. Reparos de colisao e acabamento impecavel.' },
  { icon: Hammer, title: 'Martelinho de Ouro', description: 'Reparacao de amassados sem pintura (PDR). Preserva a pintura original.' },
  { icon: Box, title: 'Cabine de Pintura', description: 'Cabine climatizada profissional com acabamento espelhado e particulas controladas.' },
  { icon: Zap, title: 'Tunning & Customizacao', description: 'Wrapping, aerografia, kits aerodinamicos, rodas e rebaixamento.' },
  { icon: Gauge, title: 'Alta Performance', description: 'Preparacao de motor, suspensao, freios, escapamento e chip tuning.' },
  { icon: Sparkles, title: 'Estetica Automotiva', description: 'Polimento tecnico, vitrificacao ceramica, higienizacao e espelhamento.' },
]

const testimonials = [
  { name: 'Carlos M.', city: 'Sao Paulo, SP', text: 'Levei meu carro batido e saiu como novo. Ney e fora de serie. 5 estrelas sem duvida.', stars: 5 },
  { name: 'Rafael A.', city: 'Sao Paulo, SP', text: 'Melhor funilaria de SP. O acabamento ficou melhor que original.', stars: 5 },
  { name: 'Bruna S.', city: 'Sao Paulo, SP', text: 'O Ney conhece cada carro de cor. Servico impecavel, prazo cumprido.', stars: 5 },
]

const vips = [
  { icon: Mic, role: 'Artista / Cantor', quote: 'Pintura exclusiva personalizada' },
  { icon: Trophy, role: 'Atleta / Esportista', quote: 'Preparacao especial de alta performance' },
  { icon: Tv, role: 'Personalidade TV', quote: 'Tunning e customizacao completa' },
]

// TODO: Substitua os IDs pelos videos reais do canal NASCAR Auto Sport
const youtubeVideos = [
  { id: 'KS_kWu9NrZQ', title: 'Transformacao Civic Si - Pintura Candy Red' },
  { id: 'dQw4w9WgXcQ', title: 'Restauracao Completa Mustang GT' },
  { id: 'jNQXAC9IVRw', title: 'Preparacao BMW M3 Track Day' },
  { id: 'xvFZjo5PgG0', title: 'Wrapping Porsche 911 - Processo Completo' },
  { id: '9bZkp7q19f0', title: 'Martelinho de Ouro - Tecnica PDR' },
  { id: 'kJQP7kiw5Fk', title: 'Tunning Golf GTI - Kit Aerodinamico' },
  { id: 'RgKAFK5djSk', title: 'Vitrificacao Ceramica 9H - Tutorial' },
  { id: 'JGwWNGJdvx8', title: 'Pintura Metalica Mercedes C300' },
]

export default function HomePage() {
  const highlightedProjects = projects.filter(p => p.highlight).slice(0, 3)
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0)
  const carouselRef = useRef<HTMLDivElement>(null)

  const nextVideo = () => {
    setCurrentVideoIndex((prev) => (prev + 1) % youtubeVideos.length)
  }

  const prevVideo = () => {
    setCurrentVideoIndex((prev) => (prev - 1 + youtubeVideos.length) % youtubeVideos.length)
  }

  const selectVideo = (index: number) => {
    setCurrentVideoIndex(index)
  }

  // Get visible videos for carousel (3 at a time on desktop, 1 on mobile)
  const getVisibleVideos = () => {
    const videos = []
    for (let i = -1; i <= 1; i++) {
      const index = (currentVideoIndex + i + youtubeVideos.length) % youtubeVideos.length
      videos.push({ ...youtubeVideos[index], originalIndex: index, position: i })
    }
    return videos
  }

  return (
    <>
      {/* ============================================ */}
      {/* BLOCO 1 — HERO SECTION */}
      {/* 
        TODO: Adicionar imagem de fundo com opacidade baixa
        Altura fixa: min-h-[700px] no desktop, min-h-[600px] no mobile
        Imagem sugerida: hero/home-bg.jpg (1920x900px)
      */}
      {/* ============================================ */}
      <section className="relative min-h-[600px] lg:min-h-[700px] flex items-center overflow-hidden gradient-hero">
        {/* Background with grain */}
        <div className="absolute inset-0 grain-overlay" />
        
        {/* 
          TODO: Descomentar quando tiver a imagem de fundo
          <div className="absolute inset-0 opacity-15">
            <Image src="/images/hero/home-bg.jpg" alt="" fill className="object-cover" />
          </div>
        */}
        
        {/* Decorative number */}
        <span className="section-number top-20 left-10 hidden lg:block">01</span>

        <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
            {/* Content */}
            <motion.div 
              className="space-y-6 lg:space-y-8"
              variants={staggerContainer}
              initial="hidden"
              animate="visible"
            >
              <motion.h1 
                className="font-[var(--font-bebas)] headline-hero text-[#F5F5F3] tracking-wide leading-none"
                variants={fadeInUp}
              >
                SEU CARRO.<br />
                <span className="text-[#FF6900] text-glow-orange">NOSSA ARTE.</span>
              </motion.h1>

              <motion.p 
                className="font-[var(--font-barlow)] text-lg lg:text-xl text-[#8A8A8A] max-w-lg leading-relaxed"
                variants={fadeInUp}
              >
                Funilaria, pintura e customizacao de alta performance em SP desde 1994
              </motion.p>

              {/* CTAs */}
              <motion.div className="flex flex-col sm:flex-row gap-4" variants={fadeInUp}>
                <a
                  href={WHATSAPP_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 bg-[#FF6900] hover:bg-[#ff8533] text-[#0a0a0a] px-6 py-4 font-[var(--font-bebas)] text-xl tracking-wide transition-all hover:shadow-[0_0_40px_rgba(255,105,0,0.4)]"
                >
                  <MessageCircle className="w-5 h-5" />
                  PEDIR ORCAMENTO
                </a>
                <Link
                  href="/projetos"
                  className="inline-flex items-center justify-center gap-2 border-2 border-[#FF6900] text-[#FF6900] hover:bg-[#FF6900] hover:text-[#0a0a0a] px-6 py-4 font-[var(--font-bebas)] text-xl tracking-wide transition-all"
                >
                  VER PROJETOS
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </motion.div>

              {/* Stats - Grid fixo para alinhamento correto */}
              <motion.div 
                className="grid grid-cols-4 gap-4 lg:gap-6 pt-6 border-t border-[rgba(255,105,0,0.2)]"
                variants={fadeInUp}
              >
                <StatBadge number="30" suffix="+" label="Anos de Mercado" />
                {/* 152K = soma de Instagram + YouTube */}
                <StatBadge number="152K" label="Seguidores" tooltip="Instagram + YouTube" />
                <StatBadge number="1000" suffix="+" label="Carros Transformados" animate={false} />
                <StatBadge number="SP" label="Capital" animate={false} />
              </motion.div>
            </motion.div>

            {/* Ney Photo Placeholder */}
            <motion.div 
              className="relative hidden lg:block"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              {/* 
                FOTO NECESSARIA: ney/ney-hero.png
                O QUE DEVE SER: Foto do Ney em PNG com fundo transparente, pose confiante, de bracos cruzados ou apontando
                DIMENSOES IDEAIS: 600x800px (portrait)
              */}
              <div className="relative aspect-[3/4] max-w-md mx-auto">
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent z-10" />
                <div className="absolute -inset-4 bg-[#FF6900]/20 blur-3xl rounded-full" />
                <div className="relative h-full bg-[#1a1a1a] flex items-center justify-center" style={{ borderRadius: '16px' }}>
                  <div className="text-center">
                    <Camera className="w-16 h-16 text-[#8A8A8A]/50 mx-auto mb-4" />
                    <span className="text-[#8A8A8A]/50 text-sm">Foto do Ney</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Scroll indicator */}
        <motion.div 
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="w-6 h-10 border-2 border-[#FF6900]/50 rounded-full flex justify-center pt-2">
            <div className="w-1.5 h-3 bg-[#FF6900] rounded-full" />
          </div>
        </motion.div>
      </section>

      {/* Separator */}
      <div className="line-separator" />

      {/* ============================================ */}
      {/* BLOCO 2 — APRESENTACAO NEY */}
      {/* ============================================ */}
      <section className="relative py-20 lg:py-32 bg-[#0a0a0a] overflow-hidden">
        <div className="absolute inset-0 grain-overlay" />
        <span className="section-number top-10 right-10 hidden lg:block">02</span>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Photo */}
            <motion.div
              className="relative"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              {/* 
                FOTO NECESSARIA: ney/ney-portrait.jpg
                O QUE DEVE SER: Foto profissional do Ney na oficina, expressao confiante
                DIMENSOES IDEAIS: 600x750px (portrait)
              */}
              <div className="relative aspect-[4/5] max-w-md mx-auto lg:mx-0">
                <div className="absolute -inset-2 bg-gradient-to-br from-[#FF6900]/30 to-transparent blur-2xl" />
                <div className="relative h-full bg-[#111111] border border-[rgba(255,105,0,0.2)] flex items-center justify-center" style={{ borderRadius: '16px' }}>
                  <div className="text-center">
                    <Camera className="w-12 h-12 text-[#8A8A8A]/50 mx-auto mb-3" />
                    <span className="text-[#8A8A8A]/50 text-sm">Foto do Ney</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Content */}
            <motion.div 
              className="space-y-6"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <span className="inline-block font-[var(--font-barlow)] text-sm font-semibold uppercase tracking-widest text-[#FF6900]">
                O DONO DA NASCAR
              </span>
              <h2 className="font-[var(--font-bebas)] headline-section text-[#F5F5F3] tracking-wide">
                Ney — 30 anos transformando carros em Sao Paulo
              </h2>
              <p className="font-sans text-[#8A8A8A] leading-relaxed text-lg">
                Desde crianca apaixonado por carros, Ney fundou a NASCAR Auto Sport em 1994 com uma missao: 
                transformar sonhos automotivos em realidade. Com mais de 30 anos de experiencia, ele se tornou 
                referencia em Sao Paulo pela qualidade impecavel do trabalho e pelo atendimento personalizado.
              </p>
              <p className="font-sans text-[#8A8A8A] leading-relaxed">
                Hoje, alem de comandar a oficina, Ney compartilha seu conhecimento com mais de 152 mil seguidores 
                nas redes sociais (Instagram + YouTube), mostrando os bastidores das transformacoes e dando dicas para os amantes de carros.
              </p>

              {/* Badges */}
              <div className="flex flex-wrap gap-4 pt-4">
                <div className="flex items-center gap-2 bg-[#111111] border border-[rgba(255,105,0,0.2)] px-4 py-2">
                  <Youtube className="w-4 h-4 text-[#FF0000]" />
                  <span className="font-[var(--font-barlow)] text-sm text-[#F5F5F3]">Youtuber</span>
                </div>
                <div className="flex items-center gap-2 bg-[#111111] border border-[rgba(255,105,0,0.2)] px-4 py-2">
                  <Star className="w-4 h-4 text-[#FF6900]" />
                  <span className="font-[var(--font-barlow)] text-sm text-[#F5F5F3]">Referencia em SP</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Separator */}
      <div className="line-separator" />

      {/* ============================================ */}
      {/* BLOCO 3 — SERVICOS DESTAQUES */}
      {/* ============================================ */}
      <section className="relative py-20 lg:py-32 gradient-mesh-secondary overflow-hidden">
        <div className="absolute inset-0 grain-overlay" />
        <span className="section-number top-10 left-10 hidden lg:block">03</span>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader 
            tag="Nossos Servicos"
            title="O QUE FAZEMOS"
            center
          />

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12"
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-100px' }}
          >
            {services.map((service, index) => (
              <ServiceCard 
                key={index}
                icon={service.icon}
                title={service.title}
                description={service.description}
              />
            ))}
          </motion.div>

          <motion.div 
            className="flex justify-center mt-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Link
              href="/servicos"
              className="inline-flex items-center gap-2 border-2 border-[#FF6900] text-[#FF6900] hover:bg-[#FF6900] hover:text-[#0a0a0a] px-6 py-3 font-[var(--font-bebas)] text-lg tracking-wide transition-all"
            >
              VER TODOS OS SERVICOS
              <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Separator */}
      <div className="line-separator" />

      {/* ============================================ */}
      {/* BLOCO 4 — PROJETOS EM DESTAQUE */}
      {/* ============================================ */}
      <section className="relative py-20 lg:py-32 bg-[#0a0a0a] overflow-hidden">
        <div className="absolute inset-0 grain-overlay" />
        <span className="section-number top-10 right-10 hidden lg:block">04</span>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader 
            tag="Portfolio"
            title="PROJETOS QUE FALAM POR SI"
            center
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
            {highlightedProjects.map((project) => (
              <ProjectCard key={project.id} project={project} featured={project.highlight} />
            ))}
          </div>

          <motion.div 
            className="flex justify-center mt-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Link
              href="/projetos"
              className="inline-flex items-center gap-2 bg-[#FF6900] hover:bg-[#ff8533] text-[#0a0a0a] px-6 py-4 font-[var(--font-bebas)] text-xl tracking-wide transition-all hover:shadow-[0_0_30px_rgba(255,105,0,0.4)]"
            >
              VER TODOS OS PROJETOS
              <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Separator */}
      <div className="line-separator" />

      {/* ============================================ */}
      {/* BLOCO 5 — YOUTUBE CARROSSEL */}
      {/* ============================================ */}
      <section className="relative py-20 lg:py-32 bg-[#111111] overflow-hidden">
        <div className="absolute inset-0 grain-overlay" />
        <span className="section-number top-10 left-10 hidden lg:block">05</span>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <span className="inline-flex items-center gap-2 font-[var(--font-barlow)] text-sm font-semibold uppercase tracking-widest text-[#FF6900] mb-4">
              <Play className="w-4 h-4" /> CANAL NO YOUTUBE
            </span>
            <h2 className="font-[var(--font-bebas)] headline-section text-[#F5F5F3] tracking-wide">
              ACOMPANHE O NEY NO YOUTUBE
            </h2>
            <p className="font-sans text-[#8A8A8A] mt-4 max-w-2xl mx-auto">
              Mais de 20 anos de conteudo automotivo. Acompanhe as transformacoes, 
              bastidores da oficina, dicas de manutencao e muito mais.
            </p>
          </div>

          {/* Video Carousel */}
          <div className="relative" ref={carouselRef}>
            {/* Main Video */}
            <motion.div 
              className="aspect-video max-w-4xl mx-auto bg-[#0a0a0a] relative overflow-hidden mb-8"
              style={{ borderRadius: '8px' }}
              key={currentVideoIndex}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <iframe
                src={`https://www.youtube.com/embed/${youtubeVideos[currentVideoIndex].id}`}
                title={youtubeVideos[currentVideoIndex].title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                loading="lazy"
                className="absolute inset-0 w-full h-full"
              />
            </motion.div>

            {/* Carousel Navigation */}
            <div className="flex items-center justify-center gap-4 mb-6">
              <button
                onClick={prevVideo}
                className="w-12 h-12 flex items-center justify-center bg-[#1a1a1a] border border-[rgba(255,105,0,0.3)] text-[#FF6900] hover:bg-[#FF6900] hover:text-[#0a0a0a] transition-all"
                style={{ borderRadius: '50%' }}
                aria-label="Video anterior"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              
              <span className="font-[var(--font-barlow)] text-[#8A8A8A] text-sm">
                <span className="text-[#FF6900] font-bold">{currentVideoIndex + 1}</span> / {youtubeVideos.length}
              </span>

              <button
                onClick={nextVideo}
                className="w-12 h-12 flex items-center justify-center bg-[#1a1a1a] border border-[rgba(255,105,0,0.3)] text-[#FF6900] hover:bg-[#FF6900] hover:text-[#0a0a0a] transition-all"
                style={{ borderRadius: '50%' }}
                aria-label="Proximo video"
              >
                <ChevronRightIcon className="w-6 h-6" />
              </button>
            </div>

            {/* Thumbnail Strip */}
            <div className="flex gap-3 overflow-x-auto pb-4 scrollbar-hide -mx-4 px-4 lg:justify-center">
              {youtubeVideos.map((video, index) => (
                <button
                  key={video.id}
                  onClick={() => selectVideo(index)}
                  className={`relative flex-shrink-0 w-32 lg:w-40 aspect-video overflow-hidden transition-all ${
                    index === currentVideoIndex 
                      ? 'ring-2 ring-[#FF6900] scale-105' 
                      : 'opacity-60 hover:opacity-100'
                  }`}
                  style={{ borderRadius: '4px' }}
                >
                  {/* YouTube Thumbnail */}
                  <img
                    src={`https://img.youtube.com/vi/${video.id}/mqdefault.jpg`}
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                  {/* Play overlay */}
                  <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                    <Play className={`w-6 h-6 ${index === currentVideoIndex ? 'text-[#FF6900]' : 'text-white'}`} fill={index === currentVideoIndex ? '#FF6900' : 'white'} />
                  </div>
                </button>
              ))}
            </div>

            {/* Current video title */}
            <p className="text-center font-[var(--font-barlow)] text-[#F5F5F3] font-semibold mt-4">
              {youtubeVideos[currentVideoIndex].title}
            </p>
          </div>

          {/* Subscribe CTA */}
          <div className="text-center mt-10">
            <a
              href={YOUTUBE_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#FF0000] hover:bg-[#cc0000] text-white px-8 py-4 font-[var(--font-bebas)] text-xl tracking-wide transition-all"
            >
              <Youtube className="w-6 h-6" />
              INSCREVER-SE NO CANAL
            </a>
          </div>
        </div>
      </section>

      {/* Separator */}
      <div className="line-separator" />

      {/* ============================================ */}
      {/* BLOCO 6 — INSTAGRAM SOCIAL PROOF */}
      {/* ============================================ */}
      <section className="relative py-20 lg:py-32 bg-[#0a0a0a] overflow-hidden">
        <div className="absolute inset-0 grain-overlay" />
        <span className="section-number top-10 right-10 hidden lg:block">06</span>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="inline-flex items-center gap-2 font-[var(--font-barlow)] text-sm font-semibold uppercase tracking-widest text-[#FF6900] mb-4">
              <Instagram className="w-4 h-4" /> INSTAGRAM
            </span>
            <h2 className="font-[var(--font-bebas)] headline-section text-[#F5F5F3] tracking-wide">
              @nascarautosport
            </h2>
          </div>

          {/* Instagram Grid */}
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            {Array.from({ length: 6 }).map((_, index) => (
              <motion.div
                key={index}
                className="relative aspect-square bg-[#1a1a1a] group cursor-pointer overflow-hidden"
                style={{ borderRadius: '4px' }}
                whileHover={{ scale: 1.02 }}
              >
                {/* 
                  FOTO NECESSARIA: social/instagram-[index].jpg
                  O QUE DEVE SER: Post do Instagram da NASCAR (print ou foto)
                  DIMENSOES IDEAIS: 400x400px (quadrada)
                */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <Camera className="w-8 h-8 text-[#8A8A8A]/30" />
                </div>
                
                {/* Hover overlay */}
                <div className="absolute inset-0 bg-[#FF6900]/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Heart className="w-8 h-8 text-white" />
                </div>
              </motion.div>
            ))}
          </motion.div>

          <div className="text-center mt-8 space-y-4">
            <p className="font-sans text-[#8A8A8A]">
              Siga a NASCAR no Instagram e acompanhe os projetos em tempo real
            </p>
            <a
              href={INSTAGRAM_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#F77737] text-white px-6 py-3 font-[var(--font-bebas)] text-lg tracking-wide transition-all hover:opacity-90"
            >
              <Instagram className="w-5 h-5" />
              SEGUIR @nascarautosport
            </a>
          </div>
        </div>
      </section>

      {/* Separator */}
      <div className="line-separator" />

      {/* ============================================ */}
      {/* BLOCO 7 — DEPOIMENTOS */}
      {/* ============================================ */}
      <section className="relative py-20 lg:py-32 gradient-mesh-secondary overflow-hidden">
        <div className="absolute inset-0 grain-overlay" />
        <span className="section-number top-10 left-10 hidden lg:block">07</span>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader 
            tag="Avaliacoes"
            title="O QUE NOSSOS CLIENTES DIZEM"
            center
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
            {testimonials.map((testimonial, index) => (
              <TestimonialCard 
                key={index}
                name={testimonial.name}
                city={testimonial.city}
                text={testimonial.text}
                stars={testimonial.stars}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Separator */}
      <div className="line-separator" />

      {/* ============================================ */}
      {/* BLOCO 8 — FAMOSOS E VIPs */}
      {/* ============================================ */}
      <section className="relative py-20 lg:py-32 bg-[#0a0a0a] overflow-hidden">
        <div className="absolute inset-0 grain-overlay" />
        <span className="section-number top-10 right-10 hidden lg:block">08</span>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader 
            tag="Clientes Especiais"
            title="QUEM CONFIA NA NASCAR"
            subtitle="Artistas, atletas e personalidades que ja passaram pela nossa oficina"
            center
          />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            {vips.map((vip, index) => (
              <motion.div
                key={index}
                className="relative bg-[#111111] border border-[#FF6900]/30 p-6 lg:p-8 text-center"
                style={{ borderRadius: '8px' }}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                {/* 
                  FOTO NECESSARIA: clients/vip-[index].jpg
                  O QUE DEVE SER: Foto do cliente VIP ou silhueta
                  DIMENSOES IDEAIS: 120x120px (quadrada)
                */}
                <div className="w-20 h-20 mx-auto mb-4 bg-[#1a1a1a] border border-[#FF6900]/20 flex items-center justify-center" style={{ borderRadius: '50%' }}>
                  <vip.icon className="w-8 h-8 text-[#FF6900]" />
                </div>
                <h3 className="font-[var(--font-barlow)] font-bold text-[#F5F5F3] text-lg mb-2">
                  {vip.role}
                </h3>
                <p className="font-sans text-[#8A8A8A] text-sm italic">
                  &ldquo;{vip.quote}&rdquo;
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Separator */}
      <div className="line-separator" />

      {/* ============================================ */}
      {/* BLOCO 9 — CTA FINAL */}
      {/* ============================================ */}
      <CTASection 
        headline="PRONTO PARA TRANSFORMAR SEU CARRO?"
        subheadline="Peca seu orcamento agora. Atendemos em Sao Paulo."
        buttonText="FALAR COM O NEY NO WHATSAPP"
        buttonLink={WHATSAPP_LINK}
        variant="orange"
      />
    </>
  )
}
