'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronRight, MessageCircle, Star, Zap, Filter } from 'lucide-react'
import { ProjectCard } from '@/components/ui/project-card'
import { projects, categoryLabels, type ProjectCategory } from '@/data/projects'

const WHATSAPP_LINK = 'https://wa.me/5511999999999'

type FilterCategory = ProjectCategory | 'todos' | 'famosos'

const filterOptions: { value: FilterCategory; label: string; icon?: React.ElementType; special?: boolean }[] = [
  { value: 'todos', label: 'Todos' },
  { value: 'famosos', label: 'Famosos', icon: Star, special: true },
  { value: 'tunning', label: 'Tunning', icon: Zap, special: true },
  { value: 'funilaria-pintura', label: 'Funilaria & Pintura' },
  { value: 'estetica', label: 'Estética' },
  { value: 'performance', label: 'Alta Performance' },
  { value: 'martelinho', label: 'Martelinho de Ouro' },
]

export default function ProjetosPage() {
  const [activeFilter, setActiveFilter] = useState<FilterCategory>('todos')

  const filteredProjects = activeFilter === 'todos' 
    ? projects 
    : activeFilter === 'famosos'
    ? projects.filter(p => p.isFamoso === true)
    : projects.filter(p => p.category === activeFilter)

  return (
    <>
      {/* ============================================ */}
      {/* BLOCO 1 — HERO DA PÁGINA */}
      {/* 
        TODO: Adicionar imagem de fundo com opacidade baixa
        Altura fixa: min-h-[400px] no desktop, min-h-[300px] no mobile
        Imagem sugerida: hero/projetos-bg.jpg (1920x600px)
      */}
      {/* ============================================ */}
      <section className="relative min-h-[300px] lg:min-h-[400px] flex items-end pb-12 lg:pb-16 gradient-hero overflow-hidden">
        <div className="absolute inset-0 grain-overlay" />
        
        {/* 
          TODO: Descomentar quando tiver a imagem de fundo
          <div className="absolute inset-0 opacity-20">
            <Image src="/images/hero/projetos-bg.jpg" alt="" fill className="object-cover" />
          </div>
        */}
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          {/* Breadcrumb */}
          <motion.nav 
            className="flex items-center gap-2 text-sm mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Link href="/" className="text-[#8A8A8A] hover:text-[#FF6900] transition-colors">
              Home
            </Link>
            <ChevronRight className="w-4 h-4 text-[#8A8A8A]" />
            <span className="text-[#FF6900]">Projetos</span>
          </motion.nav>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-[var(--font-bebas)] headline-hero text-[#F5F5F3] tracking-wide mb-4">
              NOSSOS PROJETOS
            </h1>
            <p className="font-[var(--font-barlow)] text-lg text-[#8A8A8A] max-w-2xl">
              Confira algumas das transformacoes que realizamos. Cada carro e tratado com cuidado e dedicacao.
            </p>
          </motion.div>

          {/* Project count */}
          <motion.div 
            className="mt-6 flex items-center gap-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <span className="font-[var(--font-bebas)] text-3xl text-[#FF6900]">{projects.length}</span>
            <span className="font-[var(--font-barlow)] text-[#8A8A8A] uppercase tracking-wider text-sm">
              projetos realizados
            </span>
          </motion.div>
        </div>
      </section>

      {/* ============================================ */}
      {/* BLOCO 2 — FILTROS */}
      {/* ============================================ */}
      <div className="sticky top-16 lg:top-20 z-40 bg-[#0a0a0a]/95 backdrop-blur-xl border-b border-[rgba(255,105,0,0.1)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 lg:py-4">
          {/* Desktop: Filtros em linha com contador */}
          <div className="hidden lg:flex flex-wrap items-center gap-3">
            <div className="flex flex-wrap gap-2 flex-1">
              {filterOptions.map((option) => {
                const Icon = option.icon
                const isActive = activeFilter === option.value
                
                // Estilo especial para Famosos e Tunning
                const specialStyles = option.special 
                  ? option.value === 'famosos'
                    ? isActive 
                      ? 'bg-gradient-to-r from-yellow-500 to-amber-500 text-[#0a0a0a] border-yellow-500'
                      : 'border-yellow-500/50 text-yellow-500 hover:bg-yellow-500/10'
                    : option.value === 'tunning'
                    ? isActive
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-[#0a0a0a] border-cyan-500'
                      : 'border-cyan-500/50 text-cyan-500 hover:bg-cyan-500/10'
                    : ''
                  : ''
                
                return (
                  <button
                    key={option.value}
                    onClick={() => setActiveFilter(option.value)}
                    className={`flex items-center gap-2 px-4 py-2 font-[var(--font-barlow)] text-sm font-semibold uppercase tracking-wide transition-all border ${
                      option.special
                        ? specialStyles
                        : isActive
                        ? 'bg-[#FF6900] text-[#0a0a0a] border-[#FF6900]'
                        : 'border-[rgba(255,105,0,0.3)] text-[#8A8A8A] hover:bg-[rgba(255,105,0,0.1)] hover:text-[#F5F5F3]'
                    }`}
                    style={{ borderRadius: '2px' }}
                  >
                    {Icon && <Icon className="w-4 h-4" />}
                    {option.label}
                  </button>
                )
              })}
            </div>

            {/* Counter */}
            <span className="text-[#8A8A8A] text-sm font-[var(--font-barlow)]">
              Mostrando <span className="text-[#FF6900] font-bold">{filteredProjects.length}</span> projetos
            </span>
          </div>

          {/* Mobile: Scroll horizontal compacto */}
          <div className="lg:hidden">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2 text-[#8A8A8A]">
                <Filter className="w-4 h-4" />
                <span className="text-xs font-[var(--font-barlow)] uppercase tracking-wider">Filtros</span>
              </div>
              <span className="text-xs font-[var(--font-barlow)] text-[#8A8A8A]">
                Mostrando <span className="text-[#FF6900] font-bold">{filteredProjects.length}</span> projetos
              </span>
            </div>
            
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4">
              {filterOptions.map((option) => {
                const Icon = option.icon
                const isActive = activeFilter === option.value
                
                const specialStyles = option.special 
                  ? option.value === 'famosos'
                    ? isActive 
                      ? 'bg-gradient-to-r from-yellow-500 to-amber-500 text-[#0a0a0a] border-yellow-500'
                      : 'border-yellow-500/50 text-yellow-500'
                    : option.value === 'tunning'
                    ? isActive
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-[#0a0a0a] border-cyan-500'
                      : 'border-cyan-500/50 text-cyan-500'
                    : ''
                  : ''
                
                return (
                  <button
                    key={option.value}
                    onClick={() => setActiveFilter(option.value)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 font-[var(--font-barlow)] text-xs font-semibold uppercase tracking-wide transition-all border whitespace-nowrap flex-shrink-0 ${
                      option.special
                        ? specialStyles
                        : isActive
                        ? 'bg-[#FF6900] text-[#0a0a0a] border-[#FF6900]'
                        : 'border-[rgba(255,105,0,0.3)] text-[#8A8A8A]'
                    }`}
                    style={{ borderRadius: '2px' }}
                  >
                    {Icon && <Icon className="w-3 h-3" />}
                    {option.label}
                  </button>
                )
              })}
            </div>
          </div>
        </div>
      </div>

      {/* ============================================ */}
      {/* BLOCO 3 — GRID DE PROJETOS */}
      {/* ============================================ */}
      <section className="py-12 lg:py-20 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            layout
          >
            <AnimatePresence mode="popLayout">
              {filteredProjects.map((project) => (
                <ProjectCard 
                  key={project.id} 
                  project={project} 
                  featured={project.highlight}
                />
              ))}
            </AnimatePresence>
          </motion.div>

          {/* Empty state */}
          {filteredProjects.length === 0 && (
            <motion.div 
              className="text-center py-20"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <p className="font-[var(--font-barlow)] text-[#8A8A8A] text-lg">
                Nenhum projeto encontrado nesta categoria.
              </p>
            </motion.div>
          )}
        </div>
      </section>

      {/* Separator */}
      <div className="line-separator" />

      {/* ============================================ */}
      {/* BLOCO 4 — CTA INFERIOR */}
      {/* ============================================ */}
      <section className="py-16 lg:py-24 gradient-mesh-secondary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h2 
            className="font-[var(--font-bebas)] headline-section text-[#F5F5F3] tracking-wide mb-4"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            QUER FAZER PARTE DOS NOSSOS PROJETOS?
          </motion.h2>
          <motion.p 
            className="font-[var(--font-barlow)] text-[#8A8A8A] text-lg mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            Entre em contato e veja o que podemos fazer pelo seu carro.
          </motion.p>
          <motion.a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[#FF6900] hover:bg-[#ff8533] text-[#0a0a0a] px-8 py-4 font-[var(--font-bebas)] text-xl tracking-wide transition-all hover:shadow-[0_0_40px_rgba(255,105,0,0.4)]"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <MessageCircle className="w-5 h-5" />
            PEDIR ORCAMENTO
          </motion.a>
        </div>
      </section>
    </>
  )
}
